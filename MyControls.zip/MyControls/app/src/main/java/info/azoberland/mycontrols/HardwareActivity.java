package info.azoberland.mycontrols;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

public class HardwareActivity extends Activity
{
    private static final int REQUEST_NETWORK_STATE = 100;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hardware_activity);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        showNetworkState();
    }

    private void showNetworkState()
    {
        if (checkSelfPermission(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED)
        {
            // Netzwerk erlaubnis ist bereits gewährt
            // d.h. Zugriff auf das Netzwerk (WLAN oder Mobil) ist ohne Einschränkungen immer möglich
            // das muss nicht explizit gewährt werden...
            // siehe https://stackoverflow.com/questions/43464282/android-does-runtime-permission-required-for-internet-and-access-network-state-i
            checkWLANAndMobilFunk();
        }
        else
        {
            // Erlaubnis noch nicht erteilt
            if(shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_NETWORK_STATE))
            {
                Toast.makeText(this, "Erlaubnis Netzwerkstatus anzuzeigen wird benötigt.", Toast.LENGTH_LONG).show();
            }

            // Erlaubnis einholen vom Benutzer
            requestPermissions(new String[]{Manifest.permission.ACCESS_NETWORK_STATE}, REQUEST_NETWORK_STATE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

             switch (requestCode)
              {
                  // MY_PERMISSIONS_REQUEST_READ_CONTACTS
                  case REQUEST_NETWORK_STATE:
                  {
                      // If request is cancelled, the result arrays are empty.
                      if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                      {
                          // permission was granted, yay! Do the
                      }
                      else
                      {
                          // permission denied, boo! Disable the
                          // functionality that depends on this permission.
                      }
                      return;
                  }

                  default:
                      break;
                  // other 'case' lines to check for other
                  // permissions this app might request.
              }
    }

   private void checkWLANAndMobilFunk()
   {
       ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
       NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
       TextView tvWifi =  findViewById(R.id.tvWifiStatus);

       FrameLayout layoutGPS = findViewById(R.id.layoutGPS);
       layoutGPS.setClickable(false);

       if (activeNetwork != null)
       {
           switch (activeNetwork.getType())
           {
               case ConnectivityManager.TYPE_WIFI:
                   // Mit WLAN verbunden -> billig
                   tvWifi.setText("WLAN ON: " + activeNetwork.getTypeName());
                   layoutGPS.setClickable(true);
                   break;
               case ConnectivityManager.TYPE_MOBILE:
                   // Mit Mobilfunk-Betreiber in Internet -> teuer
                   tvWifi.setText("MobilFunk ON: " + activeNetwork.getTypeName());
                   layoutGPS.setClickable(true);
                   break;
                   default:
                       tvWifi.setText("Connectivity Type ??: " + activeNetwork.getTypeName());
                       break;
           }
       }
       else
       {
           // WIFI nicht eingeschaltet
           tvWifi.setText("Kein aktives Netzwerk gefunden.");
       }
   }
    public void onClickGPS(View view)
    {
        final Intent intent = new Intent(this, GpsActivity.class);
        startActivity(intent);
    }
}
