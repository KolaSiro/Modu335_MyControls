package info.azoberland.mycontrols;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class MeldungenActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meldungen);
    }

    @Override
    protected void onStart()
    {
        super.onStart();

        // Toast Meldung
        Toast.makeText(this, "Ich bin eine Meldung mit 'Toast'", Toast.LENGTH_LONG).show();


//        Snackbar snackbar = Snackbar
//                .make(coordinatorLayout, "No internet connection!", Snackbar.LENGTH_LONG)
//                .setAction("RETRY", new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                    }
//                });

    }
}
